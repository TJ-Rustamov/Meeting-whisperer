# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec file for Meeting Whisperer Windows Application
Build with: pyinstaller app_launcher.spec
"""

import sys
from pathlib import Path

# Get the project root
project_root = Path(__file__).parent.parent

block_cipher = None

a = Analysis(
    [str(Path(__file__).parent / 'app_launcher.py')],
    pathex=[
        str(project_root / 'backend'),
        str(project_root / 'launcher'),
    ],
    binaries=[
        # Add FFmpeg binary if you have it bundled
    ],
    datas=[
        # Include backend code
        (str(project_root / 'backend' / 'app'), 'app'),
        # Include frontend build
        (str(project_root / 'frontend' / 'dist'), 'frontend/dist'),
        # Include models
        (str(project_root / 'models'), 'models'),
    ],
    hiddenimports=[
        'fastapi',
        'uvicorn',
        'sqlalchemy',
        'pydantic',
        'numpy',
        'torch',
        'torchaudio',
        'faster_whisper',
        'pyannote',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludedimports=[
        'tkinter',
        'matplotlib',
        'pandas',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='MeetingWhisperer',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # Don't show console window
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(Path(__file__).parent / 'assets' / 'app.ico') if (Path(__file__).parent / 'assets' / 'app.ico').exists() else None,
)
